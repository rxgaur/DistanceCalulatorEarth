import { Component, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTable } from '@angular/material/table';
import { TodoComponent } from '../todo/todo.component';
import {FormControl} from '@angular/forms'; 
import { ApiService } from '../api.service';

export interface ToDoListItems {
  status: boolean
  title: string;
  id: number; 
  duedate
}

@Component({
  selector: 'app-todolist',
  styleUrls: ['todolist.component.css'],
  templateUrl: 'todolist.component.html',
})
export class TodolistComponent {

  constructor(public dialog: MatDialog, private api: ApiService) {}
  ELEMENT_DATA
  serializedDate:any = new FormControl((new Date().toLocaleDateString()));

  displayedColumns: string[] = ['status', 'title', 'duedate', 'action'];
  dataSource:any = [];
  @ViewChild(MatTable,{static:true}) table: MatTable<any>;
  response;
  ngOnInit() {
    
    this.ELEMENT_DATA = [
     { status : false, id: 1, title: 'Thiis is my first task of today.', duedate: this.serializedDate.value },
     { status : true, id: 2, title: 'Thiis is my second task of today.', duedate: this.serializedDate.value  },
     { status : false, id: 3, title: 'Thiis is my third task of today.', duedate: this.serializedDate.value  },
     { status : true, id: 4, title: 'Thiis is my fourth task of today.', duedate: this.serializedDate.value  },
     { status : false, id: 5, title: 'Thiis is my fifth task of today.', duedate: this.serializedDate.value  },
     { status : true, id: 6, title: 'Thiis is my six task of today.', duedate: this.serializedDate.value  },
     { status : false, id: 7, title: 'Thiis is my seven task of today.', duedate: this.serializedDate.value  },
   ];
      this.api.gettodos().subscribe(res => {
      this.response = res;
    });

    this.dataSource = typeof(this.response) == 'undefined' ? this.ELEMENT_DATA : this.response; 
  }

  addRowData(row_obj){
       this.dataSource.push({
      id: this.dataSource.length +1,
      title: row_obj.title, 
      status : row_obj.status,
      duedate: this.formatedDate(row_obj.duedate)
    });
    this.table.renderRows();
  }

  updateRowData(row_obj){
    this.dataSource = this.dataSource.filter((value,key)=>{
      if(value.id == row_obj.id){
        value.title = row_obj.title;
        value.duedate = this.formatedDate(row_obj.duedate);
      }
      return true;
    });
  }

  deleteRowData(row_obj){
    this.dataSource = this.dataSource.filter((value,key)=>{
      return value.id != row_obj.id;
    });
  }
 
  openDialog(action,obj) {
    obj.action = action;
    const dialogRef = this.dialog.open(TodoComponent, {
      width: '550px',
      data:obj
    });
 
    dialogRef.afterClosed().subscribe(result => {
      if(result.event == 'Add'){
        this.addRowData(result.data);
      }else if(result.event == 'Update'){
        this.updateRowData(result.data);
      }else if(result.event == 'Delete'){
        this.deleteRowData(result.data);
      }else if(result.event == 'Cancel'){
        this.cancelrow();
      }
    });
  }

  cancelrow(){
    this.dataSource = this.dataSource.filter((value,key)=>{
    value.duedate = this.formatedDate(value.duedate);
      return true;
    });
  }
  
   formatedDate(datevalue){
      var formatDate = new Date(datevalue);
     return formatDate.toLocaleDateString();
     } 

     todocheckbox(element){
      this.api.putTodo(element);
     }
}

