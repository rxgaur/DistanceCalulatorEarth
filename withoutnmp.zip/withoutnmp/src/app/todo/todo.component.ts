import { Component, Inject, Optional } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
export interface ToDoListItems {
  status: boolean
  title: string;
  position: number; 
  duedate
}

@Component({
  selector: 'app-todo',
  templateUrl: './todo.component.html',
  styleUrls: ['./todo.component.css']
})
export class TodoComponent {
  form
  action:string;
  local_data:any;

  constructor(
    public dialogRef: MatDialogRef<TodoComponent>,
      @Optional() @Inject(MAT_DIALOG_DATA) public data: ToDoListItems) {

    data.duedate = new Date(data.duedate);
    this.local_data = {...data};
    this.action = this.local_data.action;
  }
 
  doAction(){
    this.dialogRef.close({event:this.action,data:this.local_data});
  }
 
  closeDialog(){
    this.dialogRef.close({event:'Cancel',data:this.local_data});
  }
 
}