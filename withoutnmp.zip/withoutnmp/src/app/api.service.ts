import { Injectable } from '@angular/core';
    import { HttpClient } from '@angular/common/http';
 

@Injectable({ providedIn: 'root'})

export class ApiService {

  constructor(private http: HttpClient) {}

  gettodos(){
    return this.http.get('https://localhost:44394/api/todo')
    }
    
  posttodo(todoItem ) {
    this.http.post('https://localhost:44394/api/todo', todoItem).subscribe(res => {
      console.log(res );
    });
  }

  putTodo(todoItem){
    this.http.put(`https://localhost:44394/api/todo/${todoItem.id}`, todoItem).subscribe(res => {
      console.log(res)
    })
  }
 }

