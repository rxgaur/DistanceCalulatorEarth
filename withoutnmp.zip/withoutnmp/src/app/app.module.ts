import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ApiService } from './api.service';
import {HttpClientModule, HTTP_INTERCEPTORS} from '@angular/common/http';
import { TodolistComponent } from './todolist/todolist.component';
import { TodoComponent } from './todo/todo.component';
import {InterceptorService} from './interceptor.service';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {MyMaterialModule} from './todolist/material-module';

@NgModule({
  declarations: [
    AppComponent,
    TodolistComponent,
    TodoComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MyMaterialModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  entryComponents: [
    TodoComponent
  ],
  providers: [ApiService, {
    provide : HTTP_INTERCEPTORS,
    useClass : InterceptorService,
    multi: true
  }],
  bootstrap: [AppComponent]
})
export class AppModule { }
