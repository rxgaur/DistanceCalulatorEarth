import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: '<app-todolist></app-todolist>' 
})
export class AppComponent {
  title = 'todoappbrightwork';
}
